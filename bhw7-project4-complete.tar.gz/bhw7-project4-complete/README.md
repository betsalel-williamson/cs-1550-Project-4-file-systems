# cs-1550-Project-4-file-systems
Use FUSE to create a custom file system, managed via a single file that represents the disk device.
